filename

nb of peaks _ clay content _ saturation content 
